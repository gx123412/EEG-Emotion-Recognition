import torch
import platform

def show_version():
    print("cuda:\t",torch.cuda.is_available())
    print("GPU:\t",torch.cuda.get_device_name(0))
    print("cuda_count:\t",torch.cuda.device_count())
    print("cuda_version:\t",torch.version.cuda)
    print("cudnn_version:\t",torch.backends.cudnn.version())
    print("torch_version:\t",torch.__version__)
    print("python_version:\t",platform.python_version())


show_version()