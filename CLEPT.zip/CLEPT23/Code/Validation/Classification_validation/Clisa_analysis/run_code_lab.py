from datetime import datetime
start_time = datetime.now()
print("the current time: ", start_time)

import os
if not os.path.exists("./results"):
    os.makedirs("./results")
if not os.path.exists("./results-loo"):
    os.makedirs("./results-loo")    

import subprocess
cmds = [
    # [
    # 'python main_pretrain.py --training-fold 0 --gpu-index 0 --dataset both --cls 9 >results/0.out ',
    # 'python main_pretrain.py --training-fold 1 --gpu-index 1 --dataset both --cls 9 >results/1.out',
    # 'python main_pretrain.py --training-fold 2 --gpu-index 2 --dataset both --cls 9 >results/2.out ',
    # 'python main_pretrain.py --training-fold 3 --gpu-index 3 --dataset both --cls 9 >results/3.out',
    # 'python main_pretrain.py --training-fold 4 --gpu-index 4 --dataset both --cls 9 >results/4.out ',
    # ],

    # [
    # 'python main_pretrain.py --training-fold 5 --gpu-index 0 --dataset both --cls 9 >results/5.out',
    # 'python main_pretrain.py --training-fold 6 --gpu-index 1 --dataset both --cls 9 >results/6.out ',
    # 'python main_pretrain.py --training-fold 7 --gpu-index 2 --dataset both --cls 9 >results/7.out',
    # 'python main_pretrain.py --training-fold 8 --gpu-index 3 --dataset both --cls 9 >results/8.out ',
    # 'python main_pretrain.py --training-fold 9 --gpu-index 4 --dataset both --cls 9 >results/9.out',
    # ],

    ['python extract_pretrainFeat.py --dataset both --cls 2 >results-loo/20.out'],
    ['python running_norm.py --dataset both --cls 2 >results-loo/21.out'],
    ['python smooth_lds.py --dataset both --cls 2  >results-loo/22.out'],
    # ['python main_classify0.py --dataset both --cls 2 >results/23.out'],
    # ['python main_classify0.py --train-or-test test --dataset both --cls 2 >results/24.out'],
    ['python main_classify0.py --val-method loo --dataset both --cls 2 >results-loo/25.out'],
    ['python main_classify0.py --train-or-test test --val-method loo --dataset both --cls 2 >results-loo/26.out'],
    
    

    ['python extract_pretrainFeat.py --dataset both --cls 9 >results-loo/10.out'],
    ['python running_norm.py --dataset both --cls 9 >results-loo/11.out'],
    ['python smooth_lds.py --dataset both --cls 9 >results-loo/12.out'],
    # ['python main_classify0.py --dataset both --cls 9 >results/13.out'],
    # ['python main_classify0.py --train-or-test test --dataset both --cls 9 >results/14.out'],
    ['python main_classify0.py --val-method loo --dataset both --cls 9 >results-loo/15.out'],
    ['python main_classify0.py --train-or-test test --val-method loo --dataset both --cls 9 >results-loo/16.out'],


    ########################################################################
    # plot confusion matrix
    [
    'cp -f Clisa_results_cls2_10_folds.mat ../Clisa_results_cls2_10_folds.mat',
    'cp -f Clisa_score_cls2_10_folds.csv ../Clisa_score_cls2_10_folds.csv',
    'cp -f Clisa_results_cls2_loo.mat ../Clisa_results_cls2_loo.mat',
    'cp -f Clisa_score_cls2_loo.csv ../Clisa_score_cls2_loo.csv',

    'cp -f Clisa_results_cls9_10_folds.mat ../Clisa_results_cls9_10_folds.mat',
    'cp -f Clisa_score_cls9_10_folds.csv ../Clisa_score_cls9_10_folds.csv',
    'cp -f Clisa_results_cls9_loo.mat ../Clisa_results_cls9_loo.mat',
    'cp -f Clisa_score_cls9_loo.csv ../Clisa_score_cls9_loo.csv',
    'cd ../ && python /data/coding/Code/Validation/Classification_validation/evl.py',
    ]
    # Add more commands as needed
    
    # ['python visualize_tsne.py'],
    # ['python Topomap2.py'],
]

for cmd in cmds:
    procs = [subprocess.Popen(c, shell=True, cwd='/data/coding/Code/Validation/Classification_validation/Clisa_analysis') for c in cmd]
    print(cmd)
    for p in procs:
        p.wait()

end_time = datetime.now()
print("total time consumed:", end_time - start_time)
print("the current time ：", datetime.now())