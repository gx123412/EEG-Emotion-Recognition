import os
import torch
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import mne
import glob

# ────────────────────────────────────────────────
# 配置区（按需修改）
# ────────────────────────────────────────────────
BASE_DIR = (
    '/data/coding/Code/Validation/Classification_validation/Clisa_analysis/runs_srt/'
    'raw_28video_batch28_dataset_both_timeLen5_tf16_sf16_multiFact2_'
    'lr0.000700_wd0.015000_epochs80_randSeed7_fold10_accSel_newPre_cls9'
)
N_FOLDS = 10
FS = 250
TIME_FILTER_LEN = 60   # timeFilterLen

CH_NAMES = [
    'Fp1', 'Fp2', 'Fz',  'F3',  'F4',  'F7',  'F8',
    'FC1', 'FC2', 'FC5', 'FC6',
    'Cz',  'C3',  'C4',  'T7',  'T8',
    'CP1', 'CP2', 'CP5', 'CP6',
    'Pz',  'P3',  'P4',  'P7',  'P8',
    'PO3', 'PO4', 'Oz',  'O1',  'O2'
]

# cls9 标签名（28 段视频对应 9 类情绪）
CLASS_NAMES = ['Disgust', 'Fear', 'Sad', 'Neutral', 'Happy',
               'Tender', 'Anger', 'Surprise', 'Awe']
CLASS_VID_MAP = {0: [0,1,2], 1: [3,4,5], 2: [6,7,8], 3: [9,10,11,12],
                 4: [13,14,15], 5: [16,17,18], 6: [19,20,21],
                 7: [22,23,24], 8: [25,26,27]}   # 视频索引 → 情绪类别
# ────────────────────────────────────────────────


def load_spatial_weights(checkpoint_path):
    """从 checkpoint 提取 spatialConv 第一层权重 (n_filters, n_channs)"""
    ckpt = torch.load(checkpoint_path, map_location='cpu')
    sd = ckpt.get('state_dict', ckpt.get('model', ckpt))
    key = [k for k in sd if 'spatialConv.weight' in k][0]
    w = sd[key].detach().cpu().numpy().squeeze()   # (16, 30)
    return w


def load_time_weights(checkpoint_path):
    """从 checkpoint 提取 timeConv 第一层权重 (n_timeFilters, 1, 1, timeFilterLen)"""
    ckpt = torch.load(checkpoint_path, map_location='cpu')
    sd = ckpt.get('state_dict', ckpt.get('model', ckpt))
    key = [k for k in sd if 'timeConv.weight' in k][0]
    w = sd[key].detach().cpu().numpy().squeeze()   # (n_timeFilters, timeFilterLen)
    return w


def find_best_checkpoint(fold_dir):
    """找该 fold 下所有 checkpoint，返回编号最大的（= best epoch checkpoint）"""
    cands = sorted(glob.glob(os.path.join(fold_dir, 'checkpoint_*.pth.tar')))
    if len(cands) == 0:
        raise FileNotFoundError(f'No checkpoint found in {fold_dir}')
    # best epoch checkpoint 是 simCLR.train 保存的第一个（编号较小那个）
    # 这里按照原代码的命名逻辑取 best epoch（两个 checkpoint 中序号较小者）
    return cands[0]


# ────────────────────────────────────────────────
# 1. 跨折汇总 spatial weights
# ────────────────────────────────────────────────
all_spatial = []
all_time_w  = []

for fold in range(N_FOLDS):
    fold_dir = os.path.join(BASE_DIR, str(fold))
    try:
        ckpt_path = find_best_checkpoint(fold_dir)
        all_spatial.append(load_spatial_weights(ckpt_path))
        all_time_w.append(load_time_weights(ckpt_path))
        print(f'Fold {fold}: loaded {os.path.basename(ckpt_path)}')
    except FileNotFoundError as e:
        print(f'Fold {fold}: skipped ({e})')

all_spatial = np.stack(all_spatial, axis=0)     # (n_folds, 16, 30)
all_time_w  = np.stack(all_time_w,  axis=0)     # (n_folds, 16, 60)

# 电极重要性：各 fold 均值
importance_per_fold = np.mean(np.abs(all_spatial), axis=1)   # (n_folds, 30)
mean_importance = importance_per_fold.mean(axis=0)            # (30,)
std_importance  = importance_per_fold.std(axis=0)             # (30,)

# 归一化
def minmax(x):
    return (x - x.min()) / (x.max() - x.min() + 1e-8)

mean_imp_norm = minmax(mean_importance)
std_imp_norm  = minmax(std_importance)


# ────────────────────────────────────────────────
# 2. MNE info
# ────────────────────────────────────────────────
info = mne.create_info(ch_names=CH_NAMES, sfreq=FS, ch_types='eeg')
montage = mne.channels.make_standard_montage('standard_1020')
info.set_montage(montage)


# ────────────────────────────────────────────────
# 3. 图一：均值地形图 + 标准差地形图（稳定性分析）
# ────────────────────────────────────────────────
fig1, axes1 = plt.subplots(1, 2, figsize=(12, 5), dpi=150)

for ax, data, title in zip(
    axes1,
    [mean_imp_norm, std_imp_norm],
    ['Mean Spatial Importance\n(across 10 folds)', 'Std of Spatial Importance\n(cross-fold consistency)']
):
    im, _ = mne.viz.plot_topomap(
        data, info, axes=ax, show=False,
        cmap='YlOrRd', contours=0, sensors=True, names=CH_NAMES,
    )
    plt.colorbar(im, ax=ax, shrink=0.75, label='Normalized value')
    ax.set_title(title, fontsize=11, pad=10)

fig1.suptitle('Spatial Filter Analysis (Cross-Fold Stability)', fontsize=13, fontweight='bold')
fig1.tight_layout()
fig1.subplots_adjust(top=0.80) 
fig1.savefig('topomap_spatial_stability.png', dpi=300, bbox_inches='tight')
print('Saved: topomap_spatial_stability.png')


# ────────────────────────────────────────────────
# 4. 图二：每个滤波器的独立地形图（展示多样性）
# ────────────────────────────────────────────────
n_filters = all_spatial.shape[1]   # 16
mean_weights_per_filter = np.mean(all_spatial, axis=0)  # (16, 30)

n_cols = 4
n_rows = (n_filters + n_cols - 1) // n_cols
fig2, axes2 = plt.subplots(n_rows, n_cols, figsize=(3.5 * n_cols, 3.5 * n_rows), dpi=120)
axes2 = axes2.flatten()

for f in range(n_filters):
    imp = minmax(np.abs(mean_weights_per_filter[f]))
    im, _ = mne.viz.plot_topomap(
        imp, info, axes=axes2[f], show=False,
        cmap='RdBu_r', contours=0, sensors=True,
    )
    axes2[f].set_title(f'Filter {f+1}', fontsize=9)

for ax in axes2[n_filters:]:
    ax.set_visible(False)

fig2.suptitle('Per-filter Spatial Topomaps (mean across folds)', fontsize=13, fontweight='bold')
fig2.tight_layout()
fig2.savefig('topomap_per_filter.png', dpi=300, bbox_inches='tight')
print('Saved: topomap_per_filter.png')



print('\nAll done.')